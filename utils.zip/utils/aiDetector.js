// utils/aiDetector.js

export function detectDepartmentAndSubject(text) {
  const lowerText = text.toLowerCase();

  const departments = {
    "Computer Science": [
      "algorithm",
      "array",
      "dbms",
      "os",
      "react",
      "python",
      "java",
    ],
    Electronics: [
      "circuit",
      "diode",
      "transistor",
      "signal",
      "microcontroller",
    ],
    Mechanical: ["thermodynamics", "fluid", "engine", "machine"],
    Electrical: ["transformer", "current", "voltage", "power system"],
  };

  const subjects = {
    DSA: ["array", "linked list", "stack", "queue", "tree", "graph"],
    "Operating Systems": ["process", "deadlock", "semaphore", "cpu scheduling"],
    DBMS: ["sql", "normalization", "transaction", "acid"],
    "Web Development": ["react", "html", "css", "javascript"],
  };

  let detectedDepartment = "Unknown";
  let detectedSubject = "Unknown";

  for (const dept in departments) {
    if (departments[dept].some((word) => lowerText.includes(word))) {
      detectedDepartment = dept;
      break;
    }
  }

  for (const subject in subjects) {
    if (subjects[subject].some((word) => lowerText.includes(word))) {
      detectedSubject = subject;
      break;
    }
  }

  return { detectedDepartment, detectedSubject };
}
