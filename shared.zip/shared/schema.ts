import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Import Auth and Chat models from integrations
export * from "./models/auth";
export * from "./models/chat";

import { users } from "./models/auth";

export const subjects = [
  "Mathematics",
  "Science",
  "History",
  "Literature",
  "Computer Science",
  "Art",
  "Music",
  "Physical Education",
  "Other"
] as const;

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  studentId: varchar("student_id").references(() => users.id), // Nullable for completely anonymous or unauthenticated? Let's assume users must be logged in to ask but can choose to be anonymous.
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  isAnonymous: boolean("is_anonymous").default(true).notNull(),
  status: text("status", { enum: ["open", "closed", "flagged"] }).default("open").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const answers = pgTable("answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").references(() => questions.id, { onDelete: "cascade" }).notNull(),
  teacherId: varchar("teacher_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  isAiGenerated: boolean("is_ai_generated").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const questionsRelations = relations(questions, ({ one, many }) => ({
  student: one(users, {
    fields: [questions.studentId],
    references: [users.id],
  }),
  answers: many(answers),
}));

export const answersRelations = relations(answers, ({ one }) => ({
  question: one(questions, {
    fields: [answers.questionId],
    references: [questions.id],
  }),
  teacher: one(users, {
    fields: [answers.teacherId],
    references: [users.id],
  }),
}));

// Schemas
export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  createdAt: true,
  status: true // Status managed by backend
});

export const insertAnswerSchema = createInsertSchema(answers).omit({
  id: true,
  createdAt: true,
  isAiGenerated: true
});

// Types
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type Answer = typeof answers.$inferSelect;
export type InsertAnswer = z.infer<typeof insertAnswerSchema>;
