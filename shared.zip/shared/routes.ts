import { z } from 'zod';
import { insertQuestionSchema, insertAnswerSchema, questions, answers, subjects } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  questions: {
    list: {
      method: 'GET' as const,
      path: '/api/questions',
      input: z.object({
        subject: z.enum(subjects).optional(),
        status: z.enum(["open", "closed", "flagged"]).optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof questions.$inferSelect & { answersCount?: number }>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/questions/:id',
      responses: {
        200: z.custom<typeof questions.$inferSelect & { 
          answers: (typeof answers.$inferSelect & { teacher?: { firstName: string | null, lastName: string | null } })[] 
        }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/questions',
      input: insertQuestionSchema,
      responses: {
        201: z.custom<typeof questions.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    close: {
      method: 'PATCH' as const,
      path: '/api/questions/:id/close',
      responses: {
        200: z.custom<typeof questions.$inferSelect>(),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized,
      },
    }
  },
  answers: {
    create: {
      method: 'POST' as const,
      path: '/api/questions/:questionId/answers',
      input: z.object({
        content: z.string().min(1, "Content is required"),
      }),
      responses: {
        201: z.custom<typeof answers.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  ai: {
    categorize: {
      method: 'POST' as const,
      path: '/api/ai/categorize',
      input: z.object({ content: z.string() }),
      responses: {
        200: z.object({ subject: z.enum(subjects) }),
      },
    },
    summarize: {
        method: 'POST' as const,
        path: '/api/ai/summarize',
        input: z.object({ questionId: z.number() }),
        responses: {
            200: z.object({ summary: z.string() }),
        }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
