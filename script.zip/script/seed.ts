import { storage } from "../server/storage";
import { db } from "../server/db";
import { questions, answers, users } from "@shared/schema";
import { sql } from "drizzle-orm";

async function seed() {
  console.log("Seeding database...");

  // Create a dummy user for testing if none exists (though users are usually created via auth)
  // For seeding, we might need to insert a user directly since storage.getUser checks auth tables which we can't easily fake without a real login.
  // But wait, we can insert into the `users` table directly for seeding.
  
  // Clean up existing data (optional, be careful in prod)
  // await db.delete(answers);
  // await db.delete(questions);
  
  // Check if we have users
  let [user] = await db.select().from(users).limit(1);
  if (!user) {
      console.log("Creating seed user...");
      [user] = await db.insert(users).values({
          id: "seed-user-1",
          email: "teacher@example.com",
          firstName: "John",
          lastName: "Doe"
      }).returning();
  }

  // Check questions
  const existingQuestions = await storage.getQuestions();
  if (existingQuestions.length === 0) {
    console.log("Creating questions...");
    const q1 = await storage.createQuestion({
        studentId: user.id,
        subject: "Science",
        content: "Why is the sky blue?",
        isAnonymous: true,
        status: "open"
    });

    const q2 = await storage.createQuestion({
        studentId: user.id,
        subject: "Mathematics",
        content: "What is the derivative of e^x?",
        isAnonymous: true,
        status: "open"
    });

    console.log("Creating answers...");
    await storage.createAnswer({
        questionId: q1.id,
        teacherId: user.id,
        content: "The sky is blue due to Rayleigh scattering.",
        isAiGenerated: false
    });
  }

  console.log("Seeding complete!");
}

seed().catch(console.error);
