export const DEPARTMENTS = [
  "Computer Science",
  "Mathematics",
  "Electronics",
  "Mechanical",
  "Civil",
];
