export type Teacher = {
  id: string;
  name: string;
  subject: string;
};

export const demoTeachers: Teacher[] = [
  {
    id: "1",
    name: "Demo Teacher 1",
    subject: "DSA",
  },
  {
    id: "2",
    name: "Demo Teacher 2",
    subject: "OS",
  },
];

