import { Link, useLocation } from "wouter";
import { 
  Home, 
  MessageCircleQuestion, 
  BookOpen, 
  Clock, 
  User, 
  LogOut,
  Sparkles
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { label: "Home", href: "/", icon: Home },
    { label: "My Questions", href: "/my-questions", icon: MessageCircleQuestion },
    { label: "Unanswered", href: "/unanswered", icon: Clock },
    { label: "Browse Subjects", href: "/subjects", icon: BookOpen },
  ];

  const getInitials = (name?: string) => {
    if (!name) return "U";
    return name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
  };

  return (
    <div className="flex h-screen flex-col border-r bg-card w-64 fixed left-0 top-0 z-30 hidden md:flex">
      {/* Brand */}
      <div className="p-6 border-b">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight">Cutm Doubthub</span>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer text-sm font-medium",
              location === item.href 
                ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            )}>
              <item.icon className="w-5 h-5" />
              {item.label}
            </div>
          </Link>
        ))}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t bg-muted/20">
        <div className="flex items-center gap-3 px-2 mb-4">
          <Avatar className="h-10 w-10 border-2 border-background shadow-sm">
            <AvatarImage src={user?.profileImageUrl || undefined} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {getInitials(user?.firstName || user?.email)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate">
              {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : 'User'}
            </p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="w-full justify-start gap-2 text-muted-foreground hover:text-destructive hover:border-destructive/30"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}
