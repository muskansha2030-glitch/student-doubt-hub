import { useState } from "react";
import { useQuestions } from "@/hooks/use-questions";
import { QuestionCard } from "@/components/QuestionCard";
import { CreateQuestionDialog } from "@/components/CreateQuestionDialog";
import { Loader2, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { subjects } from "@shared/schema";

export default function Dashboard() {
  const [subjectFilter, setSubjectFilter] = useState("all");
  const { data: questions, isLoading } = useQuestions({ 
    subject: subjectFilter !== "all" ? subjectFilter : undefined 
  });

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-6xl mx-auto w-full">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Recent Questions</h1>
          <p className="text-muted-foreground mt-1">Discover what students are asking right now.</p>
        </div>
        <CreateQuestionDialog />
      </div>

      {/* Filters & Search */}
      <div className="bg-card rounded-xl border p-4 shadow-sm flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search questions..." className="pl-10 bg-background" />
        </div>
        
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={subjectFilter} onValueChange={setSubjectFilter}>
            <SelectTrigger className="w-full md:w-[200px] bg-background">
              <SelectValue placeholder="Filter by Subject" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Subjects</SelectItem>
              {subjects.map(s => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="mt-4 text-muted-foreground animate-pulse">Loading questions...</p>
        </div>
      ) : questions?.length === 0 ? (
        <div className="text-center py-20 bg-muted/20 rounded-2xl border border-dashed">
          <h3 className="text-xl font-bold text-foreground">No questions yet</h3>
          <p className="text-muted-foreground mt-2 mb-6">Be the first to ask something!</p>
          <CreateQuestionDialog />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {questions?.map((question) => (
            <QuestionCard key={question.id} question={question} />
          ))}
        </div>
      )}
    </div>
  );
}
