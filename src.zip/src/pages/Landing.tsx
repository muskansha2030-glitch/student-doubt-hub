import { Link } from "wouter";
import { Sparkles, ArrowRight, ShieldCheck, Zap, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col font-sans selection:bg-primary/20">
      {/* Header */}
      <header className="w-full border-b bg-background/80 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            <span className="text-xl font-display font-bold">
              Cutm Doubthub
            </span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/api/login">
              <Button variant="ghost" className="font-medium">
                Sign In
              </Button>
            </a>
            <a href="/api/login">
              <Button className="shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all">
                Get Started
              </Button>
            </a>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 sm:py-32">
          {/* Abstract background blobs */}
          <div className="absolute -top-20 -right-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl opacity-50 animate-pulse" />
          <div className="absolute top-40 -left-20 w-72 h-72 bg-accent/10 rounded-full blur-3xl opacity-50" />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center max-w-3xl mx-auto space-y-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium border border-primary/20">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                AI Moderation • Anonymous • No Question Editing
              </div>

              <h1 className="text-4xl sm:text-6xl lg:text-7xl font-display font-bold tracking-tight text-foreground leading-[1.1]">
                Ask Questions <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                  Fearlessly.
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                An anonymous doubt hub where AI detects department, subject, and
                vulgarity — while teachers answer without knowing the student.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                <a href="/api/login" className="w-full sm:w-auto">
                  <Button
                    size="lg"
                    className="w-full h-12 px-8 text-base shadow-xl shadow-primary/20 hover:scale-105 transition-transform"
                  >
                    Start Asking Now <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </a>
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto h-12 px-8 text-base bg-background/50 backdrop-blur border-primary/10 hover:bg-muted/50"
                >
                  Browse Subjects
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 bg-muted/30 border-y">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6 text-primary">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display mb-3">
                  100% Anonymous
                </h3>
                <p className="text-muted-foreground">
                  Your identity is protected. Ask the "stupid" questions without
                  fear of judgment from peers or teachers.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-6 text-accent-foreground">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display mb-3">
                  AI Powered
                </h3>
                <p className="text-muted-foreground">
                  Smart categorization and instant summaries help you find
                  answers faster than ever before.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="bg-card p-8 rounded-2xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-6 text-primary">
                  <Globe className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold font-display mb-3">
                  Subject Experts
                </h3>
                <p className="text-muted-foreground">
                  Connect with teachers and experts across various fields, from
                  Mathematics to History.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-8 text-center text-sm text-muted-foreground border-t">
        <p>© 2024 Cutm Doubthub. All rights reserved.</p>
      </footer>
    </div>
  );
}
