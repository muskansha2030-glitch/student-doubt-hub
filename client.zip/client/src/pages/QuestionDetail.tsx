import { useRoute } from "wouter";
import { useQuestion, useCreateAnswer, useSummarizeQuestion } from "@/hooks/use-questions";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, ArrowLeft, User, Sparkles, MessageSquare, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Separator } from "@/components/ui/separator";

const answerSchema = z.object({
  content: z.string().min(1, "Answer cannot be empty"),
});

export default function QuestionDetail() {
  const [, params] = useRoute("/question/:id");
  const id = parseInt(params?.id || "0");
  const { data: question, isLoading } = useQuestion(id);
  const { user } = useAuth();
  
  const createAnswer = useCreateAnswer();
  const summarize = useSummarizeQuestion();
  const { toast } = useToast();

  const form = useForm({
    resolver: zodResolver(answerSchema),
    defaultValues: { content: "" },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!question) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-8">
        <h2 className="text-2xl font-bold mb-2">Question not found</h2>
        <Button variant="outline" onClick={() => window.history.back()}>Go Back</Button>
      </div>
    );
  }

  const onSubmit = async (values: { content: string }) => {
    try {
      await createAnswer.mutateAsync({ questionId: id, content: values.content });
      form.reset();
    } catch (error) {
      // handled in hook
    }
  };

  const handleSummarize = async () => {
    try {
      const result = await summarize.mutateAsync(id);
      toast({
        title: "AI Summary",
        description: result.summary,
        duration: 8000,
      });
    } catch (error) {
      // handled in hook
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Button variant="ghost" className="pl-0 hover:pl-2 transition-all" onClick={() => window.history.back()}>
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
      </Button>

      <div className="space-y-6">
        <div className="flex flex-wrap items-center gap-3">
          <Badge className="px-3 py-1 text-sm bg-primary/10 text-primary hover:bg-primary/20 border-0">
            {question.subject}
          </Badge>
          <span className="text-sm text-muted-foreground">
            Asked {formatDistanceToNow(new Date(question.createdAt), { addSuffix: true })}
          </span>
        </div>

        <h1 className="text-2xl md:text-3xl font-display font-bold leading-relaxed">
          {question.content}
        </h1>

        <div className="flex items-center gap-3 text-muted-foreground pb-6 border-b">
          <div className="p-2 rounded-full bg-muted">
            <User className="w-5 h-5" />
          </div>
          <span className="font-medium">
            {question.isAnonymous ? "Anonymous Student" : "Student"}
          </span>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold font-display flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-primary" />
            {question.answers.length} Answers
          </h2>
          
          {question.answers.length > 1 && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleSummarize}
              disabled={summarize.isPending}
              className="border-accent text-accent-foreground hover:bg-accent/10"
            >
              {summarize.isPending ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4 mr-2 text-accent-foreground" />
              )}
              AI Summarize
            </Button>
          )}
        </div>

        <div className="space-y-4">
          {question.answers.map((answer) => (
            <Card key={answer.id} className="border-border/60 shadow-sm overflow-hidden">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
                      T
                    </div>
                    <div>
                      <p className="text-sm font-semibold">
                        {answer.teacher?.firstName ? `${answer.teacher.firstName} ${answer.teacher.lastName || ''}` : "Teacher"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(answer.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                  {answer.teacherId === user?.id && (
                     <Badge variant="outline" className="text-xs">You</Badge>
                  )}
                </div>
                
                <div className="prose prose-sm max-w-none text-foreground">
                   {answer.content}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Separator className="my-8" />

        <div className="bg-muted/30 p-6 rounded-2xl border">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-green-600" />
            Your Answer
          </h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Textarea 
                        placeholder="Write a helpful answer..." 
                        className="min-h-[120px] bg-background resize-y"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end">
                <Button type="submit" disabled={createAnswer.isPending}>
                  {createAnswer.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Post Answer
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
