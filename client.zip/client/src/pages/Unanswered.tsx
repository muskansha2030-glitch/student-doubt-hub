import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { QuestionCard } from "@/components/QuestionCard";
import { Loader2, Clock } from "lucide-react";

export default function Unanswered() {
  const { data: questions, isLoading } = useQuery({
    queryKey: [api.questions.list.path],
    queryFn: async () => {
      const res = await fetch(api.questions.list.path);
      if (!res.ok) throw new Error("Failed");
      return api.questions.list.responses[200].parse(await res.json());
    },
  });

  const unansweredQuestions = questions?.filter(q => (q.answersCount || 0) === 0) || [];

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-6xl mx-auto w-full">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
          <Clock className="w-8 h-8 text-orange-500" />
          Unanswered Questions
        </h1>
        <p className="text-muted-foreground mt-1">These students are still waiting for help. Can you answer?</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {unansweredQuestions.map((question) => (
             <QuestionCard key={question.id} question={question} />
          ))}
          {unansweredQuestions.length === 0 && (
             <p className="col-span-full text-center py-10 text-muted-foreground">All questions have been answered! Great job.</p>
          )}
        </div>
      )}
    </div>
  );
}
