import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { QuestionCard } from "@/components/QuestionCard";
import { Loader2, MessageCircleQuestion } from "lucide-react";
import { CreateQuestionDialog } from "@/components/CreateQuestionDialog";

export default function MyQuestions() {
  // Using a custom filter logic on frontend for MVP, 
  // ideally backend should support ?studentId=me
  const { data: questions, isLoading } = useQuery({
    queryKey: [api.questions.list.path], // We fetch all then filter
    queryFn: async () => {
      const res = await fetch(api.questions.list.path);
      if (!res.ok) throw new Error("Failed");
      return api.questions.list.responses[200].parse(await res.json());
    },
  });

  // Since authentication is handled via cookies, the backend could easily filter by user.
  // Assuming for now the list endpoint returns ALL questions, so this page might 
  // show everything unless backend filters. 
  // NOTE: For a real app, I'd add a specific endpoint /api/my-questions
  
  return (
    <div className="p-4 md:p-8 space-y-8 max-w-6xl mx-auto w-full">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground flex items-center gap-3">
            <MessageCircleQuestion className="w-8 h-8 text-primary" />
            My Questions
          </h1>
          <p className="text-muted-foreground mt-1">Questions you have asked the community.</p>
        </div>
        <CreateQuestionDialog />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {questions?.map((question) => (
             <QuestionCard key={question.id} question={question} />
          ))}
          {questions?.length === 0 && (
             <p className="col-span-full text-center py-10 text-muted-foreground">You haven't asked any questions yet.</p>
          )}
        </div>
      )}
    </div>
  );
}
