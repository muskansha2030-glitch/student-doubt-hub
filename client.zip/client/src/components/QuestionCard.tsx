import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { MessageCircle, User, AlertCircle, CheckCircle2 } from "lucide-react";
import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Question } from "@shared/schema";

interface QuestionCardProps {
  question: Question & { answersCount?: number };
}

export function QuestionCard({ question }: QuestionCardProps) {
  const isResolved = question.status === "closed";
  
  return (
    <Link href={`/question/${question.id}`}>
      <div className="group cursor-pointer">
        <Card className="h-full border-border/50 hover:border-primary/50 hover:shadow-lg transition-all duration-300 overflow-hidden relative">
          {/* Subtle accent line on top */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          
          <CardHeader className="pb-3 space-y-2">
            <div className="flex items-start justify-between gap-4">
              <Badge variant="secondary" className="bg-primary/5 text-primary hover:bg-primary/10 transition-colors font-medium">
                {question.subject}
              </Badge>
              {isResolved ? (
                <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
                  <CheckCircle2 className="w-3 h-3 mr-1" /> Resolved
                </Badge>
              ) : (
                <span className="text-xs text-muted-foreground font-medium">
                  {formatDistanceToNow(new Date(question.createdAt), { addSuffix: true })}
                </span>
              )}
            </div>
          </CardHeader>
          
          <CardContent className="pb-6">
            <p className="font-display text-lg font-semibold leading-relaxed line-clamp-3 text-foreground group-hover:text-primary transition-colors">
              {question.content}
            </p>
          </CardContent>
          
          <CardFooter className="pt-0 flex items-center justify-between text-sm text-muted-foreground border-t bg-muted/10 p-4">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-full bg-background border shadow-sm">
                <User className="w-3 h-3" />
              </div>
              <span className="font-medium">
                {question.isAnonymous ? "Anonymous Student" : "Student"}
              </span>
            </div>
            
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-background border shadow-sm">
              <MessageCircle className="w-4 h-4 text-primary" />
              <span className="font-bold text-foreground">{question.answersCount || 0}</span>
              <span className="text-xs">answers</span>
            </div>
          </CardFooter>
        </Card>
      </div>
    </Link>
  );
}
