import { Link, useLocation } from "wouter";
import { Home, MessageCircleQuestion, Clock, BookOpen, Menu, Sparkles } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const [location] = useLocation();
  const { logout } = useAuth();

  const navItems = [
    { label: "Home", href: "/", icon: Home },
    { label: "My Questions", href: "/my-questions", icon: MessageCircleQuestion },
    { label: "Unanswered", href: "/unanswered", icon: Clock },
    { label: "Browse Subjects", href: "/subjects", icon: BookOpen },
  ];

  return (
    <div className="md:hidden flex items-center justify-between p-4 border-b bg-background/80 backdrop-blur sticky top-0 z-50">
      <Link href="/" className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-primary" />
        <span className="font-display font-bold text-lg">Cutm Doubthub</span>
      </Link>

      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon">
            <Menu className="w-5 h-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[300px] sm:w-[400px]">
          <div className="flex flex-col h-full py-6">
            <div className="px-2 mb-8">
              <span className="font-display font-bold text-2xl">Cutm Doubthub</span>
            </div>
            
            <nav className="flex-1 space-y-2">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <div className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors cursor-pointer text-sm font-medium",
                    location === item.href 
                      ? "bg-primary text-primary-foreground" 
                      : "text-muted-foreground hover:bg-muted"
                  )}>
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </div>
                </Link>
              ))}
            </nav>

            <Button variant="destructive" className="w-full mt-auto" onClick={() => logout()}>
              Sign Out
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
