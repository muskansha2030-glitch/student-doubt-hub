import { Input } from "@/components/ui/input";
import { detectDepartmentAndSubject } from "@/utils/aiDetector";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import type { Teacher } from "../data/teachers";
import { demoTeachers } from "../data/teachers";
import { insertQuestionSchema, subjects } from "@shared/schema";
import {
  useCreateQuestion,
  useCategorizeQuestion,
} from "@/hooks/use-questions";
import { Loader2, Sparkles, Send } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import * as z from "zod";

const formSchema = insertQuestionSchema.extend({
  subject: z.string().min(1, "Please select a subject"),
  department: z.string().min(1, "Department is required"),
});

export function CreateQuestionDialog() {
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [showAI, setShowAI] = useState<boolean>(false);
  const [detectedDepartment, setDetectedDepartment] = useState("Unknown");
  const [detectedSubject, setDetectedSubject] = useState("Unknown");
  const [teachers, setTeachers] = useState<Teacher[]>([]);

  const createMutation = useCreateQuestion();
  const categorizeMutation = useCategorizeQuestion();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
      subject: "",
      department: "",
      isAnonymous: true,
    },
  });
  const handleAIDetection = async (text: string) => {
    const result = await detectDepartmentAndSubject(text);

    setDetectedDepartment(result.department);
    setDetectedSubject(result.subject);

    setTeachers(demoTeachers);
    setShowAI(true);

    if (result.department !== "Unknown") {
      form.setValue("department", result.department);
    }

    if (result.subject !== "Unknown") {
      form.setValue("subject", result.subject);
    }
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      await createMutation.mutateAsync(values);
      setOpen(false);
      form.reset();
      setShowAI(false);
      setTeachers([]);
    } catch (error) {
      // handled by mutation
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-ask-question">
          Ask a Question
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Ask a Question</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* QUESTION FIELD */}
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Question</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Type your doubt here(no name or roll number required)" 
                    />
                  </FormControl>

                  <FormMessage />

                  {showAI && (
                    <div className="mt-3 border p-3 rounded-lg">
                      <p>
                        <strong>Department:</strong> {detectedDepartment}
                      </p>
                      <p>
                        <strong>Subject:</strong> {detectedSubject}
                      </p>
                    </div>
                  )}

                  {showAI && teachers.length > 0 && (
                    <div className="mt-3 border p-3 rounded-lg">
                      <p className="font-medium">Recommended Teachers</p>

                      {teachers.map((t) => (
                        <div key={t.id} className="border p-2 rounded-md">
                          <p>{t.name}</p>
                          <p className="text-xs">{t.subject}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </FormItem>
              )}
            />

            {/* AUTO DETECTED FIELDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <Input {...field} disabled />
                    </FormControl>
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input {...field} disabled />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit">Post Question</Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
