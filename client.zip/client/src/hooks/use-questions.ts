import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertQuestion, InsertAnswer, Question, Answer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// ============================================
// QUESTIONS HOOKS
// ============================================

export function useQuestions(filters?: { subject?: string; status?: "open" | "closed" | "flagged" }) {
  return useQuery({
    queryKey: [api.questions.list.path, filters],
    queryFn: async () => {
      // Build query string manually since filters are optional
      const params = new URLSearchParams();
      if (filters?.subject && filters.subject !== "all") params.append("subject", filters.subject);
      if (filters?.status) params.append("status", filters.status);
      
      const url = `${api.questions.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch questions");
      return api.questions.list.responses[200].parse(await res.json());
    },
  });
}

export function useQuestion(id: number) {
  return useQuery({
    queryKey: [api.questions.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.questions.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch question");
      return api.questions.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateQuestion() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: InsertQuestion) => {
      const res = await fetch(api.questions.create.path, {
        method: api.questions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to create question");
      }
      return api.questions.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.questions.list.path] });
      toast({
        title: "Question Posted",
        description: "Your question has been posted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// ============================================
// ANSWERS HOOKS
// ============================================

export function useCreateAnswer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ questionId, content }: { questionId: number; content: string }) => {
      const url = buildUrl(api.answers.create.path, { questionId });
      const res = await fetch(url, {
        method: api.answers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to post answer");
      }
      return api.answers.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.questions.get.path, variables.questionId] });
      // Also invalidate list as answer count might change if we tracked it there
      queryClient.invalidateQueries({ queryKey: [api.questions.list.path] });
      toast({
        title: "Answer Posted",
        description: "Your answer has been added.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

// ============================================
// AI HOOKS
// ============================================

export function useCategorizeQuestion() {
  return useMutation({
    mutationFn: async (content: string) => {
      const res = await fetch(api.ai.categorize.path, {
        method: api.ai.categorize.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content }),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to categorize");
      return api.ai.categorize.responses[200].parse(await res.json());
    },
  });
}

export function useSummarizeQuestion() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (questionId: number) => {
      const res = await fetch(api.ai.summarize.path, {
        method: api.ai.summarize.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ questionId }),
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Failed to summarize");
      return api.ai.summarize.responses[200].parse(await res.json());
    },
    onError: () => {
      toast({
        title: "AI Error",
        description: "Failed to generate summary. Try again later.",
        variant: "destructive"
      });
    }
  });
}
