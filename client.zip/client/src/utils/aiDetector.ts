export function detectDepartmentAndSubject(
  content: string
): { department: string; subject: string } {
  const lowerContent = content.toLowerCase();

  const subjectKeywords: Record<string, string[]> = {
    "Data Structures": [
      "array",
      "linked list",
      "tree",
      "graph",
      "stack",
      "queue",
      "hash",
      "sorting",
      "searching",
      "data structure",
    ],
    "Algorithms": [
      "algorithm",
      "complexity",
      "big o",
      "recursion",
      "dynamic programming",
      "greedy",
    ],
    "Operating Systems": [
      "process",
      "thread",
      "memory",
      "scheduling",
      "deadlock",
      "operating system",
      "os",
      "kernel",
    ],
    "Database Management": [
      "sql",
      "database",
      "query",
      "table",
      "normalization",
      "dbms",
      "mysql",
      "postgres",
    ],
    "Computer Networks": [
      "network",
      "tcp",
      "ip",
      "http",
      "protocol",
      "router",
      "packet",
      "osi",
    ],
    "Web Development": [
      "html",
      "css",
      "javascript",
      "react",
      "frontend",
      "backend",
      "api",
      "web",
    ],
    "Machine Learning": [
      "machine learning",
      "neural network",
      "deep learning",
      "ai",
      "model",
      "training",
      "classification",
    ],
    "Mathematics": [
      "calculus",
      "algebra",
      "matrix",
      "probability",
      "statistics",
      "math",
      "equation",
    ],
  };

  // 🔒 FIXED department mapping (demo-safe)
  const departmentMapping: Record<string, string> = {
    "Data Structures": "Computer Science",
    "Algorithms": "Computer Science",
    "Operating Systems": "Computer Science",
    "Database Management": "Computer Science",
    "Computer Networks": "Computer Science",
    "Web Development": "Computer Science",
    "Machine Learning": "Computer Science",

    // 🔥 DEMO RULE:
    // Even maths questions go to CS so teachers appear
    "Mathematics": "Computer Science",
  };

  for (const [subject, keywords] of Object.entries(subjectKeywords)) {
    for (const keyword of keywords) {
      if (lowerContent.includes(keyword)) {
        return {
          department: departmentMapping[subject],
          subject,
        };
      }
    }
  }

  // ✅ FALLBACK (never General)
  return {
    department: "Computer Science",
    subject: "Data Structures",
  };
}

