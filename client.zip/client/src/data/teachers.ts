export interface Teacher {
  id: string;
  name: string;
  department: string;
  subject: string;
  email: string;
}

export const demoTeachers: Teacher[] = [
  {
    id: "1",
    name: "Dr. Sharma",
    department: "Computer Science",
    subject: "Data Structures",
    email: "sharma@university.edu"
  },
  {
    id: "2",
    name: "Prof. Gupta",
    department: "Computer Science",
    subject: "Algorithms",
    email: "gupta@university.edu"
  },
  {
    id: "3",
    name: "Dr. Patel",
    department: "Computer Science",
    subject: "Operating Systems",
    email: "patel@university.edu"
  },
  {
    id: "4",
    name: "Prof. Singh",
    department: "Computer Science",
    subject: "Database Management",
    email: "singh@university.edu"
  },
  {
    id: "5",
    name: "Dr. Kumar",
    department: "Computer Science",
    subject: "Computer Networks",
    email: "kumar@university.edu"
  },
  {
    id: "6",
    name: "Prof. Verma",
    department: "Computer Science",
    subject: "Web Development",
    email: "verma@university.edu"
  },
  {
    id: "7",
    name: "Dr. Reddy",
    department: "Computer Science",
    subject: "Machine Learning",
    email: "reddy@university.edu"
  },
  {
    id: "8",
    name: "Prof. Joshi",
    department: "Mathematics",
    subject: "Mathematics",
    email: "joshi@university.edu"
  },
  {
    id: "9",
    name: "Dr. Mehta",
    department: "Physics",
    subject: "Physics",
    email: "mehta@university.edu"
  },
  {
    id: "10",
    name: "Prof. Agarwal",
    department: "Chemistry",
    subject: "Chemistry",
    email: "agarwal@university.edu"
  }
];
