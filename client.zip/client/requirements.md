## Packages
framer-motion | For smooth page transitions and micro-interactions
date-fns | For human-readable relative dates (e.g., "2 hours ago")

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Outfit'", "sans-serif"],
  body: ["'DM Sans'", "sans-serif"],
}
