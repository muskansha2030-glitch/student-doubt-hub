import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import { 
  questions, answers, users,
  type Question, type InsertQuestion, 
  type Answer, type InsertAnswer,
  type User
} from "@shared/schema";

export interface IStorage {
  // Questions
  createQuestion(question: InsertQuestion): Promise<Question>;
  getQuestion(id: number): Promise<Question | undefined>;
  getQuestions(filters?: { subject?: string, status?: string }): Promise<Question[]>;
  updateQuestionStatus(id: number, status: "open" | "closed" | "flagged"): Promise<Question | undefined>;
  
  // Answers
  createAnswer(answer: InsertAnswer): Promise<Answer>;
  getAnswers(questionId: number): Promise<(Answer & { teacher?: { firstName: string | null, lastName: string | null } })[]>;
  
  // Users (helper)
  getUser(id: string): Promise<User | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createQuestion(question: InsertQuestion): Promise<Question> {
    const [newQuestion] = await db.insert(questions).values(question).returning();
    return newQuestion;
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    const [question] = await db.select().from(questions).where(eq(questions.id, id));
    return question;
  }

  async getQuestions(filters?: { subject?: string, status?: string }): Promise<Question[]> {
    const conditions = [];
    if (filters?.subject) {
      conditions.push(eq(questions.subject, filters.subject));
    }
    if (filters?.status) {
      conditions.push(eq(questions.status, filters.status as any));
    }
    
    return db.select()
      .from(questions)
      .where(and(...conditions))
      .orderBy(desc(questions.createdAt));
  }

  async updateQuestionStatus(id: number, status: "open" | "closed" | "flagged"): Promise<Question | undefined> {
    const [updated] = await db.update(questions)
      .set({ status })
      .where(eq(questions.id, id))
      .returning();
    return updated;
  }

  async createAnswer(answer: InsertAnswer): Promise<Answer> {
    const [newAnswer] = await db.insert(answers).values(answer).returning();
    return newAnswer;
  }

  async getAnswers(questionId: number): Promise<(Answer & { teacher?: { firstName: string | null, lastName: string | null } })[]> {
    const result = await db.select({
      answer: answers,
      teacher: {
        firstName: users.firstName,
        lastName: users.lastName
      }
    })
    .from(answers)
    .leftJoin(users, eq(answers.teacherId, users.id))
    .where(eq(answers.questionId, questionId))
    .orderBy(desc(answers.createdAt));
    
    return result.map(row => ({
      ...row.answer,
      teacher: row.teacher
    }));
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
}

export const storage = new DatabaseStorage();
