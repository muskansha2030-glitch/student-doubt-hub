import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { openai } from "./replit_integrations/audio/client"; // Reusing openai client from integration
import { subjects } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Questions
  app.get(api.questions.list.path, async (req, res) => {
    const filters = {
      subject: req.query.subject as string | undefined,
      status: req.query.status as string | undefined
    };
    const questions = await storage.getQuestions(filters);
    
    // Enrich with answer counts (could be optimized with a join count query)
    const questionsWithCounts = await Promise.all(questions.map(async (q) => {
      const answers = await storage.getAnswers(q.id);
      return { ...q, answersCount: answers.length };
    }));
    
    res.json(questionsWithCounts);
  });

  app.get(api.questions.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const question = await storage.getQuestion(id);
    if (!question) {
      return res.status(404).json({ message: "Question not found" });
    }
    const answers = await storage.getAnswers(id);
    res.json({ ...question, answers });
  });

  app.post(api.questions.create.path, isAuthenticated, async (req, res) => {
    try {
      const input = api.questions.create.input.parse(req.body);
      const user = req.user as any; // Replit auth user claims
      
      const question = await storage.createQuestion({
        ...input,
        studentId: user.claims.sub,
      });
      res.status(201).json(question);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.patch(api.questions.close.path, isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const question = await storage.getQuestion(id);
    
    if (!question) {
        return res.status(404).json({ message: "Question not found" });
    }

    const user = req.user as any;
    // Only allow author to close (or maybe admin/teacher logic later)
    if (question.studentId !== user.claims.sub) {
        return res.status(403).json({ message: "Not authorized" });
    }

    const updated = await storage.updateQuestionStatus(id, "closed");
    res.json(updated);
  });

  // Answers
  app.post(api.answers.create.path, isAuthenticated, async (req, res) => {
    try {
        const questionId = parseInt(req.params.questionId);
        const { content } = req.body;
        const user = req.user as any;

        const question = await storage.getQuestion(questionId);
        if (!question) {
            return res.status(404).json({ message: "Question not found" });
        }

        const answer = await storage.createAnswer({
            questionId,
            teacherId: user.claims.sub,
            content,
            isAiGenerated: false
        });

        res.status(201).json(answer);
    } catch (err) {
        res.status(500).json({ message: "Internal Server Error" });
    }
  });

  // AI Routes
  app.post(api.ai.categorize.path, isAuthenticated, async (req, res) => {
    try {
        const { content } = req.body;
        
        const response = await openai.chat.completions.create({
            model: "gpt-5.1",
            messages: [
                { role: "system", content: `You are a helpful assistant that categorizes questions into one of the following subjects: ${subjects.join(", ")}. Return only the subject name.` },
                { role: "user", content: `Categorize this question: "${content}"` }
            ]
        });

        const subject = response.choices[0].message.content?.trim();
        // Validate if it matches one of our subjects, fallback to Other
        const matchedSubject = subjects.find(s => s === subject) || "Other";
        
        res.json({ subject: matchedSubject });
    } catch (err) {
        console.error("AI Categorization Error:", err);
        res.status(500).json({ message: "Failed to categorize" });
    }
  });

  app.post(api.ai.summarize.path, isAuthenticated, async (req, res) => {
      try {
          const { questionId } = req.body;
          const answers = await storage.getAnswers(questionId);
          
          if (answers.length === 0) {
              return res.json({ summary: "No answers to summarize yet." });
          }

          const answersText = answers.map(a => a.content).join("\n---\n");
          
          const response = await openai.chat.completions.create({
            model: "gpt-5.1",
            messages: [
                { role: "system", content: "Summarize the following answers into a single cohesive response." },
                { role: "user", content: answersText }
            ]
        });

        res.json({ summary: response.choices[0].message.content });

      } catch (err) {
          console.error("AI Summarization Error:", err);
          res.status(500).json({ message: "Failed to summarize" });
      }
  });

  return httpServer;
}
